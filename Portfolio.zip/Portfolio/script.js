
 document.querySelector('.ball').addEventListener('click', ()=>(
    e.target.classLits.toggle('ball-move');
    document.body.classList.toggle('dark');
 ));
        